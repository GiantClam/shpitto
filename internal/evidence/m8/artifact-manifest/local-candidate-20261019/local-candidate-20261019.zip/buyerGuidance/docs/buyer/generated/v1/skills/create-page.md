# Skill · create-page

> Source release: v1
> Canonical source: content/docs/v1/skills/create-page.mdx

# Skill · create-page

approved presentation route

Canonical invocation: read `skills/create-page/SKILL.md` and follow its evidence contract.

Add a use-case or product presentation page using approved routes and components.

## Inputs
- Page purpose, route, navigation label, metadata and content.

## Allowed scope
Approved marketing/docs routes, navigation, metadata and existing presentation components.

## Protected contracts
Do not add alternate auth, checkout, payment success, generation API or public asset behavior.

## Outputs and evidence
Record route/navigation diff, responsive and keyboard checks, content boundary result and recovery patch.

## Recovery
Remove only the new route, navigation entry and its content.

## Escalation
New server commands, protected data or public API needs engineering review.


## Release boundary

This reference describes the local governed workflow. Changes to external provider accounts, payment services, production email, payouts or protected business contracts require their separate stage evidence and are not authorized by this page.
