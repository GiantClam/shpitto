# Overview

> Source release: v1
> Canonical source: content/docs/v1/index.mdx

# Shpitto Video SaaS v1

Use the versioned navigation and published-content search to find the template,
Skills, API contracts and release guidance. Each page identifies its source
release and is also included in the offline buyer guides.

Start with the [local acceptance journey](./template/local-journey), review the
[twelve governed Skills](./skills/overview), or inspect the
[session-authenticated API contracts](./api/overview).

Documentation is rendered from trusted repository Markdown through Fumadocs.
Only published v1 pages enter navigation and search. Executable MDX and raw HTML
are not accepted by this template's documentation renderer.

The template supports a complete local Mock journey. Real provider, payment,
affiliate, merchant and production-environment verification remain separate
release gates; published documentation does not imply a stable product release.
