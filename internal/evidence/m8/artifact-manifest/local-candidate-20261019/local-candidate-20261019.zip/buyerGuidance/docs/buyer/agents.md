# Supported coding-agent discovery

The customer package exposes the same twelve files under `skills/<name>/SKILL.md`.
Codex, Claude Code and OpenCode discover them from the repository filesystem; none
of the application runtime, build or local demo requires an agent CLI.

1. Read `skills/registry.json` and select a named Skill.
2. Read that Skill's `SKILL.md` before editing.
3. Create a scoped change manifest from `.shpitto/contracts/change-manifest.json`.
4. Run the checks named by the Skill and retain their output.
5. Apply only the allowed paths. Escalate protected contract changes to an
   engineering change instead of changing them through a presentation Skill.
6. Keep a scoped recovery patch and preserve unrelated dirty work.

Codex, Claude Code and OpenCode share this filesystem discovery contract. Their
invocation syntax and tool integrations differ; the repository contract is the
portable part. A missing agent process is never a reason for the application to
fail to start.
