# Governed customization

Customization is limited to buyer-owned presentation surfaces. Start every
change with a baseline and dirty-work manifest using
`.shpitto/contracts/change-manifest.json`. The four supported workflows are:

- `customize-brand`: name, colors, logo, fonts and approved shared-shell copy.
- `create-page`: a use-case or product presentation route using existing
  navigation and components.
- `modify-page`: a declared page or component diff that keeps real bindings.
- `customize-site`: coordinated presentation changes across approved shells.

Authentication, memberships, billing and webhooks, credits, generation state,
database/migrations, asset ownership, validators and export policy are protected
contracts. If a visual request touches one of them, classify it as an
`engineering-change`, retain the impact evidence and stop the ordinary Skill.

Each change records the exact files, checks, candidate digests, reviewer and a
scoped recovery patch. Rollback must preserve unrelated dirty work and must stop
when file ownership overlaps. Export and deployment reject missing, failed or
stale validation evidence.

The local contract checks cover responsive targets 1440×900 and 390×844,
keyboard access, visible focus, semantic headings and actionable error copy.
The integrated journey check remains pending until the M4, M5 and M6 external
profiles are accepted.
