# Skill · add-generation-task

> Source release: v1
> Canonical source: content/docs/v1/skills/add-generation-task.mdx

# Skill · add-generation-task

declared generation task extension

Canonical invocation: read `skills/add-generation-task/SKILL.md` and follow its evidence contract.

Add a declared generation task only after its domain and adapter contracts are reviewed.

## Inputs
- Versioned task DTO, input/output MIME policy, provider capability and credit impact.

## Allowed scope
Task declarations, presentation forms and isolated task contract fixtures.

## Protected contracts
Do not bypass the guarded state machine, reservation, ownership checks, durable
asset validation or terminal settlement.

## Outputs and evidence
Record DTO compatibility, state transitions, credit reservation/refund behavior,
asset ownership and failure/recovery results.

## Recovery
Roll back the task declaration and its scoped fixtures; never rewrite historical
task or ledger facts.

## Escalation
Any change to state, credits, storage or migrations is an engineering change.


## Release boundary

This reference describes the local governed workflow. Changes to external provider accounts, payment services, production email, payouts or protected business contracts require their separate stage evidence and are not authorized by this page.
