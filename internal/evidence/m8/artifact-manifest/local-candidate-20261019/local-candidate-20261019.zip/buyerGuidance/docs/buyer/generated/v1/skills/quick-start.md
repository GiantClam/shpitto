# Skill · quick-start

> Source release: v1
> Canonical source: content/docs/v1/skills/quick-start.mdx

# Skill · quick-start

environment setup and local demo

Canonical invocation: read `skills/quick-start/SKILL.md` and follow its evidence contract.

Set up and inspect the persistent local no-cloud demo.

## Inputs
- Clean or explicitly recorded dirty repository baseline.
- Node 24, pnpm 12.6, Docker PostgreSQL and the checked-in `.env.example`.

## Allowed scope
Local environment files, documented setup commands and buyer guidance.

## Protected contracts
Do not change authentication, migrations, ledger, generation state, provider
adapters or validation policy through this Skill.

## Outputs and evidence
Record commands, service readiness, migration result, demo seed result and the
browser/API smoke path. Do not record secrets.

## Recovery
Stop local services and remove only the disposable local volumes created by the
setup instructions. Preserve unrelated repository changes.

## Escalation
Report a protected or production configuration request as an engineering or
deployment change.


## Release boundary

This reference describes the local governed workflow. Changes to external provider accounts, payment services, production email, payouts or protected business contracts require their separate stage evidence and are not authorized by this page.
