# Template

> Source release: v1
> Canonical source: content/docs/v1/template/index.mdx

# Template

The reviewed template provides a persistent local demo, authenticated workspaces,
private assets and server-owned commands. Use the operations page for recovery
and operator boundaries. The API page contains the current internal integration
examples and explicitly labels the deferred public API.

The shipped template fallback presentation mirrors the public Shpitto website's
shared UI baseline: a warm light canvas, coral primary, peach secondary, warm
accent, Aptos/Segoe UI typography, soft warm shadows, named focus/status states
and consistent navigation and control sizing across marketing, auth, product
and operations shells. These assets provide the initial template experience;
they are not the customer's final visual assets. The
`customize-brand` and `customize-site` Skills are the supported edit points for
replacing it with customer-selected logo, colors, fonts, copy and page
composition while preserving sign-in, workspace, generation, download and
billing journeys.
