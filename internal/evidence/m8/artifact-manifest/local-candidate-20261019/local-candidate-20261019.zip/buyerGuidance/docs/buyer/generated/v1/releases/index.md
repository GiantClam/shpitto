# Releases

> Source release: v1
> Canonical source: content/docs/v1/releases/index.mdx

# Releases

The v1 documentation source is published from the repository and exported to
buyer guidance. Each page carries a release marker and related contract IDs;
the export keeps only published source pages and strips trusted frontmatter.
External provider, payment, affiliate and production deployment evidence remains
profile-specific and is not implied by this local source.

The local candidate supports PostgreSQL, local assets, Mailpit and Mock
generation. Managed Vercel/Neon/R2/Trigger/Resend and standalone Docker are
documented as buyer-owned deployment profiles; their production activation
remains a separate evidence gate.
