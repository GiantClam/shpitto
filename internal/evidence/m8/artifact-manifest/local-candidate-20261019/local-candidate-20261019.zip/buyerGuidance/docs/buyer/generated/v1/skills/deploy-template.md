# Skill · deploy-template

> Source release: v1
> Canonical source: content/docs/v1/skills/deploy-template.mdx

# Skill · deploy-template

supported deployment configuration

Canonical invocation: read `skills/deploy-template/SKILL.md` and follow its evidence contract.

Prepare a supported deployment configuration from the checked-in deployment contract.

## Inputs
- Target profile, buyer-owned prerequisites, environment names and secret references.

## Allowed scope
Deployment templates, health checks, runbooks and redacted configuration guidance.

## Protected contracts
Never place secrets in source, enable demo drivers in production, or change migration
ordering, worker fencing or callback authentication through this Skill.

## Outputs and evidence
Record preflight checks, service readiness, migration/worker compatibility and rollback steps.

## Recovery
Use the scoped deployment rollback/runbook. Do not reset the repository or delete
unrelated infrastructure records.

## Escalation
Production changes require an authorized deployment action and separate release evidence.


## Release boundary

This reference describes the local governed workflow. Changes to external provider accounts, payment services, production email, payouts or protected business contracts require their separate stage evidence and are not authorized by this page.
