# Skills

> Source release: v1
> Canonical source: content/docs/v1/skills/overview.mdx

# Governed Skills

Skills describe bounded customization workflows. They do not grant arbitrary edits to authentication, billing, ledger, generation or release validators.
