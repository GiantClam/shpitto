# Skill · create-page

> Source release: v1
> Canonical source: content/docs/v1/skills/create-page.mdx

# Skill · create-page

approved presentation route

Canonical invocation: read `skills/create-page/SKILL.md` and follow its evidence contract.

Add a use-case or product presentation page using approved routes and components.
Start with a compact visual brief before writing JSX: audience, hierarchy,
primary action, media purpose, surface treatment, responsive topology and
reduced-motion behavior.

## Inputs
- Page purpose, route, navigation label, metadata and content.
- The shared design contract in `DESIGN.md` and `src/config/brand.ts`, plus the intended page
  pattern (hero, proof, list, form, detail or utility).

## Allowed scope
Approved marketing/docs routes, navigation, metadata and existing presentation components.
Use semantic token variables and existing shell primitives for layout, type,
color, borders, depth and controls. Keep page JavaScript small, progressive and
keyboard operable; do not add client state when a link or server-rendered
composition is sufficient.

## Protected contracts
Do not add alternate auth, checkout, payment success, generation API or public asset behavior.

## Outputs and evidence
Record route/navigation diff, visual brief, default/hover/focus/disabled state
checks, responsive and keyboard checks, content boundary result and recovery
patch.

## Recovery
Remove only the new route, navigation entry and its content.

## Escalation
New server commands, protected data or public API needs engineering review.


## Release boundary

This reference describes the local governed workflow. Changes to external provider accounts, payment services, production email, payouts or protected business contracts require their separate stage evidence and are not authorized by this page.
