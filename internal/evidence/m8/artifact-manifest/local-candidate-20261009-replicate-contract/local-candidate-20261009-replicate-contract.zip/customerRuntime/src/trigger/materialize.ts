import {readPrivateObject} from '../adapters/storage/local.ts';
import {fetchPrivateProviderOutput, type RemoteFetch} from '../adapters/storage/s3.ts';
import type {AppDatabase} from '../db/client.ts';
import type {OutputCandidate} from '../adapters/providers/port.ts';
import {materializeOutput, type MaterializeOutputResult} from '../modules/assets/ingest.ts';
import type {OutboxLease} from '../modules/generation/outbox.ts';

export async function materializeProviderOutput(db: AppDatabase, input: Readonly<{
  candidate: OutputCandidate;
  actorUserId: string;
  workspaceId: string;
  taskId: string;
  root: string;
  outboxLease?: OutboxLease;
  now?: Date;
  fetcher?: RemoteFetch;
}>): Promise<MaterializeOutputResult> {
  const source = input.candidate.kind === 'remote'
    ? await fetchPrivateProviderOutput(input.candidate.url, input.fetcher)
    : Object.freeze({bytes: new Uint8Array(await readPrivateObject(input.root, input.candidate.objectKey)), mime: 'video/mp4', sha256: '', finalUrl: input.candidate.objectKey});
  return materializeOutput(db, {
    actorUserId: input.actorUserId, workspaceId: input.workspaceId, taskId: input.taskId, root: input.root,
    bytes: source.bytes, mime: source.mime, outboxLease: input.outboxLease, now: input.now,
  });
}
