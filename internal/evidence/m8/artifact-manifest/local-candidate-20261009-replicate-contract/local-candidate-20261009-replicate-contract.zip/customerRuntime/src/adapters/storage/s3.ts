import {lookup} from 'node:dns/promises';
import {createHash} from 'node:crypto';

import {DomainError} from '../../db/contracts.ts';

export const MAX_REMOTE_OUTPUT_BYTES = 250 * 1024 * 1024;
const MAX_REDIRECTS = 3;
const ALLOWED_MIMES = new Set(['video/mp4', 'video/webm', 'video/quicktime']);

export type RemoteObject = Readonly<{bytes: Uint8Array; mime: string; sha256: string; finalUrl: string}>;
export type RemoteFetch = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
export type HostResolver = (hostname: string, options: {all: true; verbatim: true}) => Promise<ReadonlyArray<{address: string; family: number}>>;

function privateAddress(address: string): boolean {
  const normalized = address.toLowerCase();
  if (normalized === '::' || normalized === '::1' || normalized.startsWith('::ffff:')) return normalized.startsWith('::ffff:') ? privateAddress(normalized.slice(7)) : true;
  if (normalized.startsWith('fc') || normalized.startsWith('fd') || normalized.startsWith('fe80:')) return true;
  const octets = normalized.split('.').map(Number);
  if (octets.length !== 4 || octets.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  return octets[0] === 10 || octets[0] === 127 || (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31) || (octets[0] === 192 && octets[1] === 168) || (octets[0] === 169 && octets[1] === 254) || octets[0] === 0;
}

async function assertSafeOrigin(url: URL, resolveHost: HostResolver): Promise<void> {
  if (url.protocol !== 'https:' || url.username || url.password) throw new DomainError('FORBIDDEN', 'Provider output must use HTTPS without URL credentials.');
  if (privateAddress(url.hostname)) throw new DomainError('FORBIDDEN', 'Provider output cannot target a private or link-local address.');
  let records: ReadonlyArray<{address: string; family: number}>;
  try {
    records = await resolveHost(url.hostname, {all: true, verbatim: true});
  } catch {
    throw new DomainError('CONFLICT', 'Provider output hostname could not be resolved.');
  }
  if (records.length === 0 || records.some((record) => privateAddress(record.address))) throw new DomainError('FORBIDDEN', 'Provider output resolves to a private or link-local address.');
}

async function readBounded(response: Response): Promise<Uint8Array> {
  const declared = response.headers.get('content-length');
  if (declared && (!/^\d+$/.test(declared) || Number(declared) > MAX_REMOTE_OUTPUT_BYTES)) throw new DomainError('VALIDATION', 'Provider output exceeds the bounded size.');
  if (!response.body) throw new DomainError('VALIDATION', 'Provider output body is empty.');
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  for (;;) {
    const next = await reader.read();
    if (next.done) break;
    const chunk = next.value;
    size += chunk.byteLength;
    if (size > MAX_REMOTE_OUTPUT_BYTES) throw new DomainError('VALIDATION', 'Provider output exceeds the bounded size.');
    chunks.push(chunk);
  }
  const result = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.byteLength; }
  return result;
}

/** Fetch a temporary provider URL with redirect, DNS, MIME and byte limits. */
export async function fetchPrivateProviderOutput(urlText: string, fetcher: RemoteFetch = fetch, resolveHost: HostResolver = lookup): Promise<RemoteObject> {
  let url: URL;
  try { url = new URL(urlText); } catch { throw new DomainError('VALIDATION', 'Provider output URL is invalid.'); }
  for (let redirects = 0; redirects <= MAX_REDIRECTS; redirects += 1) {
    await assertSafeOrigin(url, resolveHost);
    const response = await fetcher(url, {method: 'GET', redirect: 'manual', headers: {Accept: 'video/*'}});
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get('location');
      if (!location || redirects === MAX_REDIRECTS) throw new DomainError('CONFLICT', 'Provider output redirect chain is unavailable.');
      url = new URL(location, url);
      continue;
    }
    if (!response.ok) throw new DomainError('CONFLICT', 'Provider output is unavailable.');
    const mime = (response.headers.get('content-type') ?? '').split(';', 1)[0].trim().toLowerCase();
    if (!ALLOWED_MIMES.has(mime)) throw new DomainError('VALIDATION', 'Provider output MIME type is not supported.');
    const bytes = await readBounded(response);
    return Object.freeze({bytes, mime, sha256: createHash('sha256').update(bytes).digest('hex'), finalUrl: url.toString()});
  }
  throw new DomainError('CONFLICT', 'Provider output redirect chain is unavailable.');
}
