import {and, eq, isNull, lte, ne} from 'drizzle-orm';
import {randomUUID} from 'node:crypto';
import {lstat, readdir, rename} from 'node:fs/promises';
import {relative, resolve, sep} from 'node:path';

import type {AppDatabase} from '../../db/client.ts';
import {assets} from '../../db/schema/asset.ts';
import {generationTasks} from '../../db/schema/generation.ts';
import {deletePrivateObject, readPrivateObject, resolveLocalObjectPath, writePrivateObject} from '../../adapters/storage/local.ts';

export const ORPHAN_RETENTION_MS = 24 * 60 * 60 * 1000;
/** Keep one workspace sweep bounded even if a volume contains unexpected files. */
export const MAX_ORPHAN_SCAN_OBJECTS = 1_000;

type DeleteObject = (root: string, objectKey: string) => Promise<void>;

export type CleanupOrphanedAssetsInput = Readonly<{
  workspaceId: string;
  root: string;
  now?: Date;
  /** Test/operations hook; the default is the validated local storage deleter. */
  deleteObject?: DeleteObject;
}>;

export type CleanupObjectFailure = Readonly<{
  objectKey: string;
  error: string;
  retryAt: string;
}>;

export type CleanupOrphanedAssetsReport = Readonly<{
  /** Number of pending asset rows removed after their object was collected. */
  deletedRows: number;
  /** Number of object keys successfully collected, including rowless objects. */
  deletedObjects: number;
  /** Number of regular files inspected under this workspace's storage prefixes. */
  scannedObjects: number;
  /** Object removals that failed; referenced rows remain available for retry. */
  failures: ReadonlyArray<CleanupObjectFailure>;
}>;

type Candidate = Readonly<{id: string; objectKey: string}>;

function errorMessage(error: unknown): string {
  return error instanceof Error ? `${error.name}: ${error.message}` : String(error);
}

function retryAt(now: Date): string {
  return now.toISOString();
}

function toObjectKey(root: string, path: string): string {
  return relative(resolve(root), path).split(sep).join('/');
}

/** Walk in object-key order, pruning directories already passed by the cursor. */
async function listRegularFiles(root: string, prefix: string, maxFiles: number, after: string | null): Promise<string[]> {
  const base = resolve(root, prefix);
  const files: string[] = [];
  // A prefix can have a symlink ancestor even when its final directory is real.
  let parent = resolve(root);
  for (const segment of ['', ...prefix.split('/')]) {
    parent = resolve(parent, segment);
    try {
      const entry = await lstat(parent);
      if (entry.isSymbolicLink() || !entry.isDirectory()) return files;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return files;
      throw error;
    }
  }
  const visit = async (path: string): Promise<void> => {
    if (files.length >= maxFiles) return;
    let entry;
    try {
      entry = await lstat(path);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return;
      throw error;
    }
    if (entry.isSymbolicLink()) return;
    const objectKey = toObjectKey(root, path);
    if (entry.isFile()) {
      if (!after || objectKey > after) files.push(objectKey);
      return;
    }
    if (!entry.isDirectory()) return;
    if (after && `${objectKey}/` <= after && !after.startsWith(`${objectKey}/`)) return;
    // Include the slash in directory ordering: "a.txt" precedes "a/file".
    const children = (await readdir(path, {withFileTypes: true}))
      .map((child) => ({name: child.name, sortKey: child.name + (child.isDirectory() ? '/' : '')}))
      .sort((a, b) => a.sortKey < b.sortKey ? -1 : a.sortKey > b.sortKey ? 1 : 0);
    for (const child of children) {
      const childKey = `${objectKey}/${child.name}`;
      if (after && `${objectKey}/${child.sortKey}` <= after && !after.startsWith(`${childKey}/`)) continue;
      await visit(resolve(path, child.name));
      if (files.length >= maxFiles) return;
    }
  };
  await visit(base);
  return files;
}

async function readScanCursor(root: string, cursorKey: string): Promise<string | null> {
  try {
    const value: unknown = JSON.parse((await readPrivateObject(root, cursorKey)).toString('utf8'));
    return value && typeof value === 'object' && 'after' in value && typeof value.after === 'string' ? value.after : null;
  } catch (error) {
    // A lost or interrupted cursor is only a scan hint: restarting is safe.
    if (error instanceof SyntaxError || (error as NodeJS.ErrnoException).code === 'ENOENT') return null;
    throw error;
  }
}

async function writeScanCursor(root: string, cursorKey: string, after: string | null): Promise<void> {
  const temporaryKey = `${cursorKey}.${randomUUID()}.tmp`;
  await writePrivateObject(root, temporaryKey, Buffer.from(JSON.stringify({after}), 'utf8'));
  try {
    await rename(resolveLocalObjectPath(root, temporaryKey), resolveLocalObjectPath(root, cursorKey));
  } finally {
    await deletePrivateObject(root, temporaryKey);
  }
}

async function isOldRegularFile(root: string, objectKey: string, cutoff: Date): Promise<boolean> {
  const path = resolve(root, objectKey);
  try {
    const entry = await lstat(path);
    if (entry.isSymbolicLink() || !entry.isFile()) return false;
    return entry.mtimeMs <= cutoff.getTime();
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false;
    throw error;
  }
}

async function collectPendingRows(db: AppDatabase, workspaceId: string, cutoff: Date): Promise<Candidate[]> {
  return db.transaction(async (tx) => tx.select({id: assets.id, objectKey: assets.objectKey}).from(assets).where(and(
    eq(assets.workspaceId, workspaceId),
    eq(assets.state, 'pending'),
    isNull(assets.taskId),
    lte(assets.createdAt, cutoff),
  )).for('update', {skipLocked: true}));
}

async function collectWorkspacePrefixes(db: AppDatabase, workspaceId: string): Promise<string[]> {
  const tasks = await db.select({id: generationTasks.id}).from(generationTasks).where(eq(generationTasks.workspaceId, workspaceId));
  return [`workspaces/${workspaceId}`, ...tasks.map((task) => `tasks/${task.id}`)].sort();
}

/**
 * Collect old taskless rows and rowless files for one workspace. A row is
 * deleted only after the validated filesystem removal succeeds; on failure
 * the row and its updated_at retry marker remain available for the next sweep.
 */
export async function cleanupOrphanedAssetsDetailed(db: AppDatabase, input: CleanupOrphanedAssetsInput): Promise<CleanupOrphanedAssetsReport> {
  // Validate the tenant segment before deriving any filesystem prefixes. This
  // keeps an operational caller from turning a workspace id into traversal.
  resolveLocalObjectPath(input.root, `workspaces/${input.workspaceId}/cleanup-marker`);
  const now = input.now ?? new Date();
  const cutoff = new Date(now.getTime() - ORPHAN_RETENTION_MS);
  const remove = input.deleteObject ?? deletePrivateObject;
  const failures: CleanupObjectFailure[] = [];
  let deletedRows = 0;
  let deletedObjects = 0;

  const prefixes = await collectWorkspacePrefixes(db, input.workspaceId);
  const isScopedObjectKey = (objectKey: string): boolean => prefixes.some((prefix) => objectKey === prefix || objectKey.startsWith(`${prefix}/`));
  const cursorKey = `.cleanup-cursors/${input.workspaceId}.json`;
  const savedCursor = await readScanCursor(input.root, cursorKey);
  const after = savedCursor && isScopedObjectKey(savedCursor) ? savedCursor : null;
  const candidates = await collectPendingRows(db, input.workspaceId, cutoff);
  for (const candidate of candidates) {
    if (!isScopedObjectKey(candidate.objectKey)) continue;
    const outcome = await db.transaction(async (tx) => {
      const locked = (await tx.select({id: assets.id, objectKey: assets.objectKey}).from(assets).where(and(
        eq(assets.id, candidate.id),
        eq(assets.workspaceId, input.workspaceId),
        eq(assets.state, 'pending'),
        isNull(assets.taskId),
        lte(assets.createdAt, cutoff),
      )).for('update', {skipLocked: true}))[0];
      if (!locked) return {status: 'skipped'} as const;
      // Object keys are expected to be unique, but keep the cleanup safe on a
      // partially migrated/local database where a foreign live row may still
      // reference the same key.
      const sharedReference = (await tx.select({id: assets.id}).from(assets).where(and(
        eq(assets.objectKey, locked.objectKey),
        ne(assets.id, locked.id),
        ne(assets.state, 'deleted'),
      )).limit(1))[0];
      if (sharedReference) return {status: 'skipped'} as const;
      try {
        await remove(input.root, locked.objectKey);
      } catch (error) {
        await tx.update(assets).set({updatedAt: now}).where(and(eq(assets.id, locked.id), eq(assets.workspaceId, input.workspaceId)));
        return {status: 'failed', objectKey: locked.objectKey, error: errorMessage(error)} as const;
      }
      const deleted = await tx.delete(assets).where(and(
        eq(assets.id, locked.id),
        eq(assets.workspaceId, input.workspaceId),
        eq(assets.state, 'pending'),
        isNull(assets.taskId),
      )).returning({id: assets.id});
      return {status: deleted.length === 1 ? 'deleted' : 'skipped'} as const;
    });
    if (outcome.status === 'deleted') {
      deletedRows += 1;
      deletedObjects += 1;
    } else if (outcome.status === 'failed') {
      failures.push({objectKey: outcome.objectKey, error: outcome.error, retryAt: retryAt(now)});
    }
  }

  const liveRows = await db.select({objectKey: assets.objectKey}).from(assets).where(ne(assets.state, 'deleted'));
  const referenced = new Set(liveRows.map((row) => row.objectKey));
  const physicalKeys = new Set<string>();
  for (const prefix of prefixes) {
    const remaining = MAX_ORPHAN_SCAN_OBJECTS - physicalKeys.size;
    if (remaining <= 0) break;
    for (const key of await listRegularFiles(input.root, prefix, remaining, after)) physicalKeys.add(key);
  }

  for (const objectKey of physicalKeys) {
    if (referenced.has(objectKey) || !(await isOldRegularFile(input.root, objectKey, cutoff))) continue;
    const current = await db.select({objectKey: assets.objectKey}).from(assets).where(and(
      eq(assets.objectKey, objectKey),
      ne(assets.state, 'deleted'),
    )).limit(1);
    if (current[0]) continue;
    try {
      await remove(input.root, objectKey);
      deletedObjects += 1;
    } catch (error) {
      failures.push({objectKey, error: errorMessage(error), retryAt: retryAt(now)});
    }
  }

  // Save progress only after completing the page. Failures remain eligible on
  // the next full cycle; new keys before the cursor are also found after wrap.
  const lastKey = [...physicalKeys].at(-1) ?? null;
  await writeScanCursor(input.root, cursorKey, physicalKeys.size === MAX_ORPHAN_SCAN_OBJECTS ? lastKey : null);
  return Object.freeze({deletedRows, deletedObjects, scannedObjects: physicalKeys.size, failures});
}

/** Backward-compatible count used by existing probe and worker callers. */
export async function cleanupOrphanedAssets(db: AppDatabase, input: CleanupOrphanedAssetsInput): Promise<number> {
  return (await cleanupOrphanedAssetsDetailed(db, input)).deletedRows;
}
