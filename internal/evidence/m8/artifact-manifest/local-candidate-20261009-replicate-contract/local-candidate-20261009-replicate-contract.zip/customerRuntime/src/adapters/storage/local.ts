import {lstat, mkdir, readFile, rm, writeFile} from 'node:fs/promises';
import {dirname, isAbsolute, relative, resolve, sep} from 'node:path';

import {DomainError} from '../../db/contracts.ts';

function assertObjectKey(key: string): void {
  if (!key || key.length > 512 || key.includes('\\') || key.startsWith('/') || key.includes('\0')) {
    throw new DomainError('VALIDATION', 'Asset object key is invalid.');
  }
  const segments = key.split('/');
  if (segments.some((segment) => !segment || segment === '.' || segment === '..' || !/^[A-Za-z0-9._-]+$/.test(segment))) {
    throw new DomainError('VALIDATION', 'Asset object key is invalid.');
  }
}

export function resolveLocalObjectPath(root: string, objectKey: string): string {
  assertObjectKey(objectKey);
  const rootPath = resolve(root);
  const target = resolve(rootPath, objectKey);
  const rel = relative(rootPath, target);
  if (isAbsolute(rel) || rel.startsWith(`..${sep}`) || rel === '..') {
    throw new DomainError('FORBIDDEN', 'Asset path escapes the private object root.');
  }
  return target;
}

async function assertNoSymlink(path: string): Promise<void> {
  try {
    const stat = await lstat(path);
    if (stat.isSymbolicLink()) throw new DomainError('FORBIDDEN', 'Symbolic links are not allowed for private assets.');
  } catch (error) {
    if (error instanceof DomainError) throw error;
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
  }
}

async function assertNoSymlinkChain(root: string, target: string): Promise<void> {
  const rootPath = resolve(root);
  let current = target;
  const chain: string[] = [];
  while (current !== rootPath && current.startsWith(`${rootPath}${sep}`)) {
    chain.push(current);
    current = dirname(current);
  }
  chain.push(rootPath);
  for (const path of chain.reverse()) await assertNoSymlink(path);
}

export async function writePrivateObject(root: string, objectKey: string, bytes: Uint8Array): Promise<string> {
  const target = resolveLocalObjectPath(root, objectKey);
  await assertNoSymlinkChain(root, target);
  await mkdir(dirname(target), {recursive: true});
  await assertNoSymlinkChain(root, target);
  await writeFile(target, bytes, {flag: 'wx'});
  return target;
}

export async function readPrivateObject(root: string, objectKey: string): Promise<Buffer> {
  const target = resolveLocalObjectPath(root, objectKey);
  await assertNoSymlinkChain(root, target);
  return readFile(target);
}

export async function deletePrivateObject(root: string, objectKey: string): Promise<void> {
  const target = resolveLocalObjectPath(root, objectKey);
  await assertNoSymlinkChain(root, target);
  await rm(target, {force: true});
}
