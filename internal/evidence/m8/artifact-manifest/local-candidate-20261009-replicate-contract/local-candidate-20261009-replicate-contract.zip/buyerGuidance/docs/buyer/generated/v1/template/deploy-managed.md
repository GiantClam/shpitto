# Managed deployment reference

> Source release: v1
> Canonical source: content/docs/v1/template/deploy-managed.mdx

# Managed deployment reference

The planned managed profile separates the Next.js app on Vercel, PostgreSQL on
Neon, private object storage on R2, scheduled/long-running work on Trigger.dev,
and outbound email on Resend. Each service and credential belongs to the
buyer. Keep all services in compatible regions and use the database provider's
pooled URL for request traffic and its direct URL for migrations and backups.

## Current implementation boundary

The repository contains a Vercel framework/build configuration and production
guards, but the managed R2, Resend and hosted worker deployment bindings are not
activated by this local candidate. The four real generation paths, Stripe test
mode and FirstPromoter account remain separate open gates. This page is a
preflight reference, not evidence of a production deployment or an instruction
to enter production credentials into the local profile.

## Configuration review

Set `APP_URL` to the final HTTPS origin, `DATABASE_URL` to the buyer's runtime
database URL, and `BETTER_AUTH_SECRET` to a unique secret stored in the host's
secret manager. Production rejects the local/mock driver defaults. Set
`STORAGE_DRIVER`, `GENERATION_DRIVER` and `MAIL_DRIVER` only after their selected
production adapters and matching credentials have been reviewed and deployed.

Before routing traffic, verify the health endpoint, run the reviewed Drizzle
migrations with a direct database connection, and confirm the exact candidate
in the M8 managed profile. Keep webhook secrets, provider keys, object-store
credentials and outbound-mail keys out of build arguments, source control,
browser responses and evidence logs.
