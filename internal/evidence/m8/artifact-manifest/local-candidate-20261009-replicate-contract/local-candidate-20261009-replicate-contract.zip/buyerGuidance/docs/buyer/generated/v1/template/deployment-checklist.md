# Deployment configuration checklist

> Source release: v1
> Canonical source: content/docs/v1/template/deployment-checklist.mdx

# Deployment configuration checklist

Before a production profile is considered:

1. Set `NODE_ENV=production` and a canonical HTTPS `APP_URL`.
2. Store a unique `BETTER_AUTH_SECRET` and database URLs in the host secret
   manager. Never put them in Docker build arguments or client-exposed variables.
3. Replace `STORAGE_DRIVER=local`, `GENERATION_DRIVER=mock`, and
   `MAIL_DRIVER=local` with supported, tested adapters. Production rejects the
   local defaults, but passing that guard does not prove an adapter is connected.
4. Confirm that provider webhook secrets, signing keys and account identities
   match the exact deployed provider configuration. Do not enable a model whose
   account-backed gate is open.
5. Stop old workers before applying a migration that changes fields they read.
   Run `node --experimental-strip-types scripts/migrate.ts` with the direct
   PostgreSQL connection; request traffic may use the provider's pooled URL.
6. Verify `/api/healthz`, authenticated sign-in, the supported worker path,
   private asset access and recovery monitoring before traffic is enabled.
7. Capture the deployed image digest, source/lockfile digests, migration result,
   operational owner and rollback image in release evidence.

The health route checks database reachability and reports a bounded profile and
latency result. It does not assert provider, mail, billing or affiliate health.
See the [operations guide](./operations) for the separate integration health
signals and recovery procedures.
