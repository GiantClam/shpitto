# Skill · customize-site

> Source release: v1
> Canonical source: content/docs/v1/skills/customize-site.mdx

# Skill · customize-site

shared shell and approved presentation

Canonical invocation: read `skills/customize-site/SKILL.md` and follow its evidence contract.

Coordinate approved brand, theme, content and page composition changes across
the site. The marketing, auth, product and admin shells start from the Shpitto
website baseline as a template fallback. Customer delivery uses this Skill to
compose the customer's own brand, theme and page presentation over that shell.

## Inputs
- Customer site intent, brand assets, affected shells, tokens, routes, components and release baseline.
- The shared-shell surfaces and their required loading, empty, error and
  denied states.

## Allowed scope
Approved marketing/product presentation paths, `src/config/brand.ts`,
`src/config/navigation.ts`, `src/app/globals.css` and shared shell components.

## Protected contracts
Keep sign-in, workspace navigation, generation, downloads, billing, admin and i18n boundaries intact.

## Outputs and evidence
Record the change manifest, customer asset/token overrides, all four journey
checks, desktop/mobile/accessibility results, shared navigation consistency and
recovery patch.

## Recovery
Resolve overlapping dirty work, then apply a scoped rollback without repository-wide reset.

## Escalation
Any protected contract or dependency change is classified as engineering work.


## Release boundary

This reference describes the local governed workflow. Changes to external provider accounts, payment services, production email, payouts or protected business contracts require their separate stage evidence and are not authorized by this page.
