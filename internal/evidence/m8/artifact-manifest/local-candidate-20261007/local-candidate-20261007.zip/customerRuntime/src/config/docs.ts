export type DocsEntry = Readonly<{
  title: string;
  href: string;
  summary: string;
  section: 'template' | 'skills' | 'apis' | 'releases';
  status: 'published' | 'preview';
}>;

export const docsVersion = 'v1';

export const docsNavigation: readonly DocsEntry[] = [
  {title: 'Overview', href: '/docs', summary: 'Product boundaries and implementation status.', section: 'releases', status: 'preview'},
  {title: 'Template', href: '/docs/template', summary: 'Operations and deployment boundaries.', section: 'template', status: 'preview'},
  {title: 'Skill usage', href: '/docs/skills', summary: 'Governed customization workflow preview.', section: 'skills', status: 'preview'},
  {title: 'API contracts', href: '/docs/api', summary: 'Session and command contract preview.', section: 'apis', status: 'preview'},
  {title: 'Releases', href: '/docs/releases', summary: 'Published release and source status.', section: 'releases', status: 'preview'},
];

export const docsSections = ['template', 'skills', 'apis', 'releases'] as const;
