import {SiteShell} from '../../../components/shell/site-shell';

export default function ApiDocsPage() {
  return <SiteShell><main className="page"><p className="eyebrow">API contract preview</p><h1>Server-owned commands.</h1><p>Public API keys and external write access are deferred. Private mutations use the authenticated session, a same-origin or CSRF-protected request and a bounded <code>Idempotency-Key</code>.</p><p>Responses use an <code>{'{ ok: true, data }'}</code> or <code>{'{ ok: false, error }'}</code> envelope. Credit and currency quantities cross JSON boundaries as decimal strings.</p></main></SiteShell>;
}
