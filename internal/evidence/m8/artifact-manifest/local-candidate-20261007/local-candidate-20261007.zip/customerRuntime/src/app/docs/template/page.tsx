import {SiteShell} from '../../../components/shell/site-shell';

export default function TemplateDocsPage() {
  return <SiteShell><main className="page"><p className="eyebrow">Template · v1 preview</p><h1>Operate the reviewed template.</h1><p>Use the local persistent demo, workspace and operator guides from the trusted versioned source. Production provider accounts, payment accounts and deployment credentials remain separate prerequisites.</p></main></SiteShell>;
}
