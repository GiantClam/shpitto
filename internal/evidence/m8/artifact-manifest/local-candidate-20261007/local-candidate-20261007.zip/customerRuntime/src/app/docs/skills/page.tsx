import {SiteShell} from '../../../components/shell/site-shell';

export default function SkillsDocsPage() {
  return <SiteShell><main className="page"><p className="eyebrow">Skill usage preview</p><h1>Customize through governed Skills.</h1><p>Visual edits stay inside approved presentation paths. Core auth, billing, ledger, generation and export contracts require dedicated engineering changes and trusted validation.</p></main></SiteShell>;
}
