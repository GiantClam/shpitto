const SAMPLE_VALUES = new Set([
  '',
  'replace-me',
  'change-me',
  'your-secret-here',
  'postgres://user:password@localhost:5432/database',
]);

function isSampleValue(value: string): boolean {
  return SAMPLE_VALUES.has(value) || /^(replace-me|change-me|your-)/i.test(value);
}

type ServerEnv = Readonly<{
  nodeEnv: 'development' | 'test' | 'production';
  appUrl: string;
  databaseUrl: string;
  betterAuthSecret: string;
  storageDriver: string;
  generationDriver: string;
  mailDriver: string;
  assetRoot: string;
  workerHealthUrl: string;
  mailSmtpUrl: string;
  mailHttpUrl: string;
  billingWebhookSecret: string;
  replicateWebhookSecret: string;
  replicateWebhookAccountId: string;
  falWebhookPublicKeyPem: string;
  falWebhookAccountId: string;
  affiliateReferralSecret: string;
  affiliateWebhookSecret: string;
  affiliateProgramId: string;
}>;

function read(name: string): string {
  return process.env[name]?.trim() ?? '';
}

export function getServerEnv(): ServerEnv {
  const nodeEnv = (read('NODE_ENV') || 'development') as ServerEnv['nodeEnv'];
  if (!['development', 'test', 'production'].includes(nodeEnv)) {
    throw new Error('NODE_ENV must be development, test, or production.');
  }

  const values = {
    appUrl: read('APP_URL'),
    databaseUrl: read('DATABASE_URL'),
    betterAuthSecret: read('BETTER_AUTH_SECRET'),
    storageDriver: read('STORAGE_DRIVER') || 'local',
    generationDriver: read('GENERATION_DRIVER') || 'mock',
    mailDriver: read('MAIL_DRIVER') || 'local',
    assetRoot: read('ASSET_ROOT') || './.data/assets',
    workerHealthUrl: read('WORKER_HEALTH_URL') || 'http://localhost:8080/healthz',
    mailSmtpUrl: read('MAIL_SMTP_URL') || 'smtp://localhost:1025',
    billingWebhookSecret: read('BILLING_WEBHOOK_SECRET') || (nodeEnv === 'production' ? '' : 'local-development-billing-webhook-secret'),
    replicateWebhookSecret: read('REPLICATE_WEBHOOK_SECRET'),
    replicateWebhookAccountId: read('REPLICATE_WEBHOOK_ACCOUNT_ID'),
    falWebhookPublicKeyPem: read('FAL_WEBHOOK_PUBLIC_KEY_PEM'),
    falWebhookAccountId: read('FAL_WEBHOOK_ACCOUNT_ID'),
    affiliateReferralSecret: read('AFFILIATE_REFERRAL_SECRET'),
    affiliateWebhookSecret: read('AFFILIATE_WEBHOOK_SECRET'),
    affiliateProgramId: read('AFFILIATE_PROGRAM_ID'),
  };

  if (nodeEnv === 'production') {
    // Optional integrations validate their own configuration when activated.
    // Their absent credentials must not prevent the core application starting.
    const optional = new Set(['billingWebhookSecret', 'affiliateReferralSecret', 'affiliateWebhookSecret', 'affiliateProgramId']);
    const missing = Object.entries(values)
      .filter(([name, value]) =>
        !optional.has(name) && (isSampleValue(value) ||
        (name === 'storageDriver' && value === 'local') ||
        (name === 'generationDriver' && value === 'mock') ||
        (name === 'mailDriver' && value === 'local')),
      )
      .map(([name]) => name);
    if (missing.length > 0) {
      throw new Error(`Production configuration contains empty or sample values: ${missing.join(', ')}`);
    }
  }

  return Object.freeze({nodeEnv, ...values, mailHttpUrl: read('MAIL_HTTP_URL') || 'http://localhost:8025'});
}

/** Resolve the demo-funding guard without forcing unrelated production secrets during tests. */
export function getRuntimeProfile(): 'local' | 'production' {
  return read('NODE_ENV') === 'production' ? 'production' : 'local';
}
