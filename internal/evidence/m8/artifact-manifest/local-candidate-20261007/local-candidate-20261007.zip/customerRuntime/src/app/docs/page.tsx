import {SiteShell} from '../../components/shell/site-shell';
import {docsNavigation, docsVersion} from '../../config/docs';

export default function DocsPage() {
  return (
    <SiteShell>
      <main className="page">
        <p className="eyebrow">Developer docs · {docsVersion}</p>
        <h1>Build on the reviewed contracts.</h1>
        <p>These pages introduce the template, governed Skills and API boundaries. They are source-controlled previews until the Docs milestone adds the full Fumadocs navigation.</p>
        <div className="status-card" aria-label="Documentation navigation">
          {docsNavigation.map((entry) => <p key={entry.href}><a href={entry.href}><strong>{entry.title}</strong></a> · {entry.summary} · {entry.status}</p>)}
        </div>
      </main>
    </SiteShell>
  );
}
