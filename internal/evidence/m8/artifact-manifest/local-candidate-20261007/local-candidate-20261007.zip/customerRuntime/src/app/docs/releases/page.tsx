import {SiteShell} from '../../../components/shell/site-shell';

export default function ReleasesDocsPage() {
  return <SiteShell><main className="page"><p className="eyebrow">Releases · v1 preview</p><h1>Versioned source and evidence.</h1><p>Public documentation is indexed from published repository content only. The current v1 source is an engineering preview while external provider and production deployment evidence remains pending.</p></main></SiteShell>;
}
