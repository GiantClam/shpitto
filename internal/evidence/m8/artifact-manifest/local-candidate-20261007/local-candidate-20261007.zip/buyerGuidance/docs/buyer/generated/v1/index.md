# Overview

> Source release: v1
> Canonical source: content/docs/v1/index.mdx

# Shpitto Video SaaS v1

This is the source-controlled developer documentation seed for the M1 scaffold. The full Fumadocs build is introduced after the product and Skills contracts are implemented.
